#!/bin/bash

/Applications/Google\ Chrome.app/Contents/MacOS/Google\ Chrome --disable-web-security "file://$( cd "$( dirname "$0" )" && pwd )/../sandbox/just-in-case-specrunner.html"