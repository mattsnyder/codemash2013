#!/bin/bash

brew update && brew install phantomjs