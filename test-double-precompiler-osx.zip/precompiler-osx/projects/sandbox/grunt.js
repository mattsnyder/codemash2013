/*global module:false*/
module.exports = function(grunt) {
  require('lineman').config.grunt.run(grunt);
};