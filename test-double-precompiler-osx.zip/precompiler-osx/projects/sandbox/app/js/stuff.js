var root = this;

root.subtract = function(number, otherNumber) {
  return number - otherNumber;
};