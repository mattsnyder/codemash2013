(function() {

  describe(".add", function() {
    When(function() {
      return this.result = add(5, 3);
    });
    return Then(function() {
      return expect(this.result).toEqual(8);
    });
  });

}).call(this);
