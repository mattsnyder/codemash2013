(function() {
  var root;

  root = this;

  root.add = function(number, otherNumber) {
    return number + otherNumber;
  };

}).call(this);
